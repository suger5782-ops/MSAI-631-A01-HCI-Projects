
Azure AI Traditional Chatbot
Author: Aakriti Kharel

This chatbot integrates Azure AI Language Service (Sentiment Analysis)
with a traditional rule-based chatbot.

Steps:
1. Set environment variables:
   AZURE_LANGUAGE_ENDPOINT
   AZURE_LANGUAGE_KEY
2. Install:
   pip install azure-ai-textanalytics
3. Run:
   python chatbot.py

GitHub:
https://github.com/suger5782-ops/MSAI-631-A01-HCI-Projects

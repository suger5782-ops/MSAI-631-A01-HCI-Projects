
# Azure AI Sentiment-Integrated Traditional Chatbot
# Author: Aakriti Kharel

import os
from azure.ai.textanalytics import TextAnalyticsClient
from azure.core.credentials import AzureKeyCredential

def authenticate_client():
    endpoint = os.getenv("AZURE_LANGUAGE_ENDPOINT")
    key = os.getenv("AZURE_LANGUAGE_KEY")
    if not endpoint or not key:
        print("Azure credentials not found. Set environment variables.")
        return None
    return TextAnalyticsClient(endpoint=endpoint, credential=AzureKeyCredential(key))

client = authenticate_client()

print("Welcome to the Azure AI Traditional Chatbot!")
print("Type 'help' for commands or 'exit' to quit.")

while True:
    user_input = input("You: ")
    if user_input.lower() == "exit":
        print("Bot: Goodbye!")
        break
    elif user_input.lower() == "help":
        print("Bot: I can greet you, analyze sentiment, and answer basic questions.")
    elif "hello" in user_input.lower():
        print("Bot: Hello! Nice to meet you.")
    elif client:
        try:
            response = client.analyze_sentiment([user_input])[0]
            print(f"Bot: Sentiment = {response.sentiment}, Confidence = {response.confidence_scores}")
        except Exception as e:
            print("Bot: Error analyzing sentiment.")
    else:
        print("Bot: I didn't understand. Try 'help'.")

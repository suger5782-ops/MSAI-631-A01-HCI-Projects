
# Simple Rule-Based Chatbot (Traditional Approach)
# Author: Aakriti Kharel

print("Hello! I am a simple rule-based chatbot.")
print("Type 'help' to see what I can do or 'exit' to quit.")

while True:
    user_input = input("You: ").lower()

    if user_input == "exit":
        print("Bot: Goodbye!")
        break
    elif "hello" in user_input or "hi" in user_input:
        print("Bot: Hello! How can I help you today?")
    elif "help" in user_input:
        print("Bot: I can respond to greetings, tell you my name, explain my purpose, or exit.")
    elif "name" in user_input:
        print("Bot: My name is SimpleBot.")
    elif "purpose" in user_input or "do" in user_input:
        print("Bot: I demonstrate a traditional rule-based chatbot approach.")
    else:
        print("Bot: Sorry, I didn't understand that. Try typing 'help'.")

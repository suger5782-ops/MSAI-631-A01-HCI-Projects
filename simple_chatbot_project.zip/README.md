
Simple Traditional Chatbot
Author: Aakriti Kharel

This project demonstrates a traditional rule-based chatbot using Python.
Run using: python chatbot.py
